package pl.edu.agh.dronka.shop.model;

public enum Genre {
    ROCK, POP, CLASSIC, METAL;

    public static Genre parse(String genre) {
        if (genre.equals("ROCK")) {
            return Genre.ROCK;
        }
        if (genre.equals("POP")) {
            return Genre.POP;
        }
        if (genre.equals("CLASSIC")) {
            return Genre.CLASSIC;
        }
        if (genre.equals("METAL")) {
            return Genre.METAL;
        }
    return ROCK;
    }
}
